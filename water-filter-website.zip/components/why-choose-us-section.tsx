import { Award, DollarSign, Truck, ShieldCheck } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

export function WhyChooseUsSection() {
  const reasons = [
    {
      icon: Award,
      title: "Certified Technology",
      description:
        "Our filters meet international water quality standards and are independently tested for effectiveness.",
    },
    {
      icon: DollarSign,
      title: "Affordable Pricing",
      description: "Premium quality at competitive prices. Save money compared to bottled water within months.",
    },
    {
      icon: Truck,
      title: "Fast Delivery & Support",
      description: "Local support team and quick delivery. We're here to help with installation and maintenance.",
    },
    {
      icon: ShieldCheck,
      title: "2-Year Warranty Included",
      description: "Every filter comes with a comprehensive warranty and lifetime customer support.",
    },
  ]

  return (
    <section className="py-16 md:py-24 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4 text-balance">
            Why Choose <span className="text-primary">PureFlow?</span>
          </h2>
          <p className="text-lg text-muted-foreground text-pretty">
            We're committed to providing the best water filtration experience from purchase to daily use.
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4 max-w-7xl mx-auto">
          {reasons.map((reason, index) => (
            <Card key={index} className="text-center border-2 hover:border-primary/50 transition-colors">
              <CardContent className="pt-6">
                <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <reason.icon className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-lg font-bold mb-2">{reason.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{reason.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
