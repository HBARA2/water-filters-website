import { Card, CardContent } from "@/components/ui/card"
import { Star } from "lucide-react"

export function TestimonialsSection() {
  const testimonials = [
    {
      name: "Sarah Johnson",
      role: "Homeowner",
      content:
        "After installing the under-sink filter, our water tastes amazing! No more buying expensive bottled water. Best investment for our family's health.",
      rating: 5,
    },
    {
      name: "Michael Chen",
      role: "Café Owner",
      content:
        "The commercial filter has been perfect for our café. Our customers love the coffee quality, and we've saved so much on bottled water expenses.",
      rating: 5,
    },
    {
      name: "Emily Rodriguez",
      role: "Office Manager",
      content:
        "Easy installation and excellent customer support. Our team loves having clean, filtered water available throughout the day. Highly recommended!",
      rating: 5,
    },
  ]

  return (
    <section className="py-16 md:py-24">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4 text-balance">
            What Our <span className="text-primary">Customers Say</span>
          </h2>
          <p className="text-lg text-muted-foreground text-pretty">
            Join thousands of satisfied customers who've made the switch to clean, filtered water.
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-3 max-w-6xl mx-auto">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="border-2">
              <CardContent className="pt-6">
                <div className="flex gap-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-primary text-primary" />
                  ))}
                </div>
                <p className="text-foreground leading-relaxed mb-4 italic">"{testimonial.content}"</p>
                <div>
                  <div className="font-bold">{testimonial.name}</div>
                  <div className="text-sm text-muted-foreground">{testimonial.role}</div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
