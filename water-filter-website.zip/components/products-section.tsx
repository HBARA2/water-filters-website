import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Check, Home, Wrench, Building2 } from "lucide-react"

export function ProductsSection() {
  const products = [
    {
      icon: Home,
      name: "Residential Filter",
      description: "Perfect for families and home use",
      price: "$299",
      features: [
        "Removes 99.9% of contaminants",
        "Capacity: 5,000 liters",
        "Filter lifespan: 6 months",
        "Easy countertop installation",
      ],
      image:
        "https://placehold.co/400x300?text=Modern+countertop+water+filter+unit+with+clear+blue+reservoir+in+bright+kitchen+setting",
    },
    {
      icon: Wrench,
      name: "Under-Sink Filter",
      description: "Sleek design that saves counter space",
      price: "$449",
      features: [
        "Advanced 3-stage filtration",
        "Capacity: 8,000 liters",
        "Filter lifespan: 9 months",
        "Professional installation included",
      ],
      image:
        "https://placehold.co/400x300?text=Compact+under+sink+water+filtration+system+with+chrome+faucet+and+blue+filter+cartridges",
      featured: true,
    },
    {
      icon: Building2,
      name: "Commercial Filter",
      description: "High-capacity for offices and cafés",
      price: "$799",
      features: [
        "Industrial-grade filtration",
        "Capacity: 15,000 liters",
        "Filter lifespan: 12 months",
        "Suitable for 20-50 people",
      ],
      image:
        "https://placehold.co/400x300?text=Large+capacity+commercial+water+filter+system+with+multiple+stages+in+office+environment",
    },
  ]

  return (
    <section id="products" className="py-16 md:py-24">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4 text-balance">
            Choose Your Perfect <span className="text-primary">Water Filter</span>
          </h2>
          <p className="text-lg text-muted-foreground text-pretty">
            We offer premium filtration solutions for every need, from homes to businesses.
          </p>
        </div>

        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3 max-w-7xl mx-auto">
          {products.map((product, index) => (
            <Card key={index} className={`relative ${product.featured ? "border-primary border-2 shadow-lg" : ""}`}>
              {product.featured && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 bg-primary text-primary-foreground text-sm font-bold rounded-full">
                  Most Popular
                </div>
              )}
              <CardHeader>
                <div className="w-full h-48 rounded-lg overflow-hidden mb-4">
                  <img
                    src={product.image || "/placeholder.svg"}
                    alt={`${product.name} - ${product.description}`}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-2">
                  <product.icon className="w-6 h-6 text-primary" />
                </div>
                <CardTitle className="text-2xl">{product.name}</CardTitle>
                <p className="text-muted-foreground">{product.description}</p>
              </CardHeader>
              <CardContent>
                <div className="mb-6">
                  <div className="text-4xl font-bold text-primary mb-1">{product.price}</div>
                  <div className="text-sm text-muted-foreground">One-time purchase</div>
                </div>

                <ul className="space-y-3 mb-6">
                  {product.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <Check className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                      <span className="text-sm leading-relaxed">{feature}</span>
                    </li>
                  ))}
                </ul>

                <Button className="w-full" size="lg" variant={product.featured ? "default" : "outline"}>
                  Get This Filter
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
