import { Droplet } from "lucide-react"

export function Footer() {
  return (
    <footer className="bg-foreground text-background py-12">
      <div className="container mx-auto px-4">
        <div className="flex flex-col items-center text-center space-y-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
              <Droplet className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold">PureFlow</span>
          </div>

          <p className="text-background/80 max-w-md">
            Premium water filtration solutions for homes and businesses. Clean, safe, and affordable.
          </p>

          <div className="pt-4 border-t border-background/20 w-full">
            <p className="text-sm text-background/60">
              © {new Date().getFullYear()} PureFlow Water Filters. All rights reserved.
            </p>
          </div>
        </div>
      </div>
    </footer>
  )
}
