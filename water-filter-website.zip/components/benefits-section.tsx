import { Shield, Sparkles, Leaf, Wrench } from "lucide-react"

export function BenefitsSection() {
  const benefits = [
    {
      icon: Shield,
      title: "Removes Harmful Contaminants",
      description: "Advanced filtration technology removes chlorine, lead, bacteria, and 99.9% of other impurities.",
    },
    {
      icon: Sparkles,
      title: "Crystal Clear Taste & Odor",
      description: "Enjoy fresh, clean water that tastes great. Perfect for drinking, cooking, and making beverages.",
    },
    {
      icon: Leaf,
      title: "Eco-Friendly Solution",
      description: "Reduce plastic waste by eliminating bottled water. Good for your wallet and the environment.",
    },
    {
      icon: Wrench,
      title: "Easy Installation & Maintenance",
      description: "Simple setup with our installation guide or professional help. Filter changes take just minutes.",
    },
  ]

  return (
    <section className="py-16 md:py-24 bg-gradient-to-br from-primary/5 via-background to-accent/5">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4 text-balance">
            Why Choose <span className="text-primary">Filtered Water?</span>
          </h2>
          <p className="text-lg text-muted-foreground text-pretty">
            Experience the difference clean water makes in your daily life.
          </p>
        </div>

        <div className="grid gap-8 md:grid-cols-2 max-w-5xl mx-auto">
          {benefits.map((benefit, index) => (
            <div key={index} className="flex gap-4">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                <benefit.icon className="w-6 h-6 text-primary" />
              </div>
              <div>
                <h3 className="text-xl font-bold mb-2">{benefit.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{benefit.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
