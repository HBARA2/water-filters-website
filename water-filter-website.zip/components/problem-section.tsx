import { AlertTriangle, DollarSign, Droplet } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

export function ProblemSection() {
  const problems = [
    {
      icon: AlertTriangle,
      title: "Hidden Contaminants",
      description:
        "Tap water can contain chlorine, lead, bacteria, and other harmful substances that affect your health and well-being.",
    },
    {
      icon: Droplet,
      title: "Poor Taste & Odor",
      description:
        "Unpleasant taste and smell in drinking water makes it difficult to stay hydrated and enjoy cooking with clean water.",
    },
    {
      icon: DollarSign,
      title: "Expensive Bottled Water",
      description:
        "Spending hundreds or thousands yearly on bottled water adds up fast, while creating unnecessary plastic waste.",
    },
  ]

  return (
    <section className="py-16 md:py-24 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4 text-balance">
            Is Your Water <span className="text-primary">Really Safe?</span>
          </h2>
          <p className="text-lg text-muted-foreground text-pretty">
            Most people don't realize the risks lurking in their everyday drinking water. Here's what you need to know.
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-3 max-w-6xl mx-auto">
          {problems.map((problem, index) => (
            <Card key={index} className="border-2 hover:border-primary/50 transition-colors">
              <CardContent className="pt-6">
                <div className="w-12 h-12 rounded-lg bg-destructive/10 flex items-center justify-center mb-4">
                  <problem.icon className="w-6 h-6 text-destructive" />
                </div>
                <h3 className="text-xl font-bold mb-2">{problem.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{problem.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
