import { Button } from "@/components/ui/button"
import { Droplet } from "lucide-react"

export function HeroSection() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-primary/5 via-background to-accent/5">
      <div className="container mx-auto px-4 py-20 md:py-32">
        <div className="grid gap-8 lg:grid-cols-2 lg:gap-12 items-center">
          <div className="space-y-6 text-center lg:text-left">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-primary/10 rounded-full text-sm font-medium text-primary">
              <Droplet className="w-4 h-4" />
              Certified Water Purification Technology
            </div>

            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight text-balance">
              Pure, Safe Water for Your <span className="text-primary">Family & Business</span>
            </h1>

            <p className="text-lg md:text-xl text-muted-foreground leading-relaxed text-pretty">
              Protect your health with advanced filtration systems. Remove harmful contaminants, improve taste, and save
              thousands on bottled water every year.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Button size="lg" className="text-lg h-14 px-8" asChild>
                <a href="#contact">Get a Free Quote</a>
              </Button>
              <Button size="lg" variant="outline" className="text-lg h-14 px-8 bg-transparent" asChild>
                <a href="#products">View Products</a>
              </Button>
            </div>

            <div className="flex flex-wrap gap-6 justify-center lg:justify-start pt-4 text-sm">
              <div className="flex items-center gap-2">
                <div className="w-5 h-5 rounded-full bg-primary/20 flex items-center justify-center">
                  <div className="w-2 h-2 rounded-full bg-primary"></div>
                </div>
                <span className="text-foreground font-medium">Free Installation Support</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-5 h-5 rounded-full bg-primary/20 flex items-center justify-center">
                  <div className="w-2 h-2 rounded-full bg-primary"></div>
                </div>
                <span className="text-foreground font-medium">2-Year Warranty</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-5 h-5 rounded-full bg-primary/20 flex items-center justify-center">
                  <div className="w-2 h-2 rounded-full bg-primary"></div>
                </div>
                <span className="text-foreground font-medium">Fast Delivery</span>
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-accent/20 blur-3xl rounded-full"></div>
            <img
              src="https://placehold.co/600x600?text=Modern+water+filter+system+with+clear+blue+water+flowing+through+transparent+tubes+on+clean+white+background"
              alt="Modern water filter system with clear blue water flowing through transparent tubes on clean white background"
              className="relative rounded-2xl w-full h-auto object-cover"
            />
          </div>
        </div>
      </div>
    </section>
  )
}
